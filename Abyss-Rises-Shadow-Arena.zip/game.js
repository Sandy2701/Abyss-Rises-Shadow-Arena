(() => {
  "use strict";

  const canvas = document.getElementById("gameCanvas");
  const ctx = canvas.getContext("2d", { alpha: false });

  const refs = {
    menuOverlay: document.getElementById("menuOverlay"),
    levelOverlay: document.getElementById("levelOverlay"),
    gameOverOverlay: document.getElementById("gameOverOverlay"),
    startButton: document.getElementById("startButton"),
    restartButton: document.getElementById("restartButton"),
    pauseButton: document.getElementById("pauseButton"),
    soundButton: document.getElementById("soundButton"),
    attackButton: document.getElementById("attackButton"),
    dashButton: document.getElementById("dashButton"),
    skillOneButton: document.getElementById("skillOneButton"),
    skillTwoButton: document.getElementById("skillTwoButton"),
    ultimateButton: document.getElementById("ultimateButton"),
    classCards: Array.from(document.querySelectorAll(".class-card")),
    upgradeCards: document.getElementById("upgradeCards"),
    toast: document.getElementById("toast"),
    className: document.getElementById("className"),
    levelText: document.getElementById("levelText"),
    hpBar: document.getElementById("hpBar"),
    hpText: document.getElementById("hpText"),
    staminaBar: document.getElementById("staminaBar"),
    staminaText: document.getElementById("staminaText"),
    xpBar: document.getElementById("xpBar"),
    waveText: document.getElementById("waveText"),
    scoreText: document.getElementById("scoreText"),
    goldText: document.getElementById("goldText"),
    comboText: document.getElementById("comboText"),
    rankText: document.getElementById("rankText"),
    furyBar: document.getElementById("furyBar"),
    furyText: document.getElementById("furyText"),
    finalWave: document.getElementById("finalWave"),
    finalScore: document.getElementById("finalScore"),
    bestScore: document.getElementById("bestScore"),
    runTitle: document.getElementById("runTitle")
  };

  const TAU = Math.PI * 2;
  const WORLD = { width: 3200, height: 2400 };

  const HEROES = {
    knight: {
      name: "Revenant Knight",
      hp: 150,
      stamina: 92,
      speed: 245,
      damage: 28,
      range: 118,
      crit: 0.1,
      armor: 0.18,
      attackSpeed: 1,
      color: "#d84a3d",
      accent: "#d8a95a",
      skillOne: "Rift Cyclone",
      skillTwo: "Judgment Lance",
      skillOneCd: 4.4,
      skillTwoCd: 6.2
    },
    rogue: {
      name: "Crimson Rogue",
      hp: 112,
      stamina: 118,
      speed: 305,
      damage: 22,
      range: 104,
      crit: 0.24,
      armor: 0.08,
      attackSpeed: 1.32,
      color: "#e64d56",
      accent: "#4ec09a",
      skillOne: "Scarlet Tempest",
      skillTwo: "Needle Rift",
      skillOneCd: 3.7,
      skillTwoCd: 5.4
    },
    arcanist: {
      name: "Void Arcanist",
      hp: 96,
      stamina: 134,
      speed: 255,
      damage: 25,
      range: 138,
      crit: 0.14,
      armor: 0.05,
      attackSpeed: 0.92,
      color: "#9b72e2",
      accent: "#4ec09a",
      skillOne: "Null Nova",
      skillTwo: "Astral Spear",
      skillOneCd: 4.8,
      skillTwoCd: 5.8
    }
  };

  const ENEMY_TYPES = {
    ashbound: {
      name: "Ashbound",
      hp: 54,
      damage: 13,
      speed: 118,
      radius: 18,
      reach: 18,
      xp: 18,
      score: 80,
      color: "#805046",
      accent: "#d8a95a"
    },
    sentinel: {
      name: "Rift Sentinel",
      hp: 105,
      damage: 18,
      speed: 82,
      radius: 23,
      reach: 24,
      xp: 30,
      score: 130,
      color: "#665c58",
      accent: "#d84a3d"
    },
    shade: {
      name: "Glass Shade",
      hp: 42,
      damage: 16,
      speed: 172,
      radius: 15,
      reach: 12,
      xp: 22,
      score: 105,
      color: "#4b395f",
      accent: "#9b72e2"
    },
    seer: {
      name: "Abyss Seer",
      hp: 68,
      damage: 15,
      speed: 98,
      radius: 17,
      reach: 280,
      xp: 32,
      score: 155,
      ranged: true,
      color: "#314f4a",
      accent: "#4ec09a"
    },
    boss: {
      name: "Eclipse Champion",
      hp: 780,
      damage: 24,
      speed: 98,
      radius: 44,
      reach: 34,
      xp: 210,
      score: 1200,
      boss: true,
      color: "#211c1d",
      accent: "#d8a95a"
    }
  };

  const UPGRADE_POOL = [
    {
      id: "edge",
      name: "Bloodforged Edge",
      text: "+18% attack damage.",
      apply: (p) => { p.damage *= 1.18; }
    },
    {
      id: "heart",
      name: "Cinder Heart",
      text: "+28 max health and restore health.",
      apply: (p) => {
        p.maxHp += 28;
        p.hp = Math.min(p.maxHp, p.hp + 55);
      }
    },
    {
      id: "stride",
      name: "Wraith Stride",
      text: "+11% movement speed and faster dash recovery.",
      apply: (p) => {
        p.speed *= 1.11;
        p.dashMax = Math.max(0.55, p.dashMax - 0.11);
      }
    },
    {
      id: "storm",
      name: "Storm Vessel",
      text: "+22 max stamina and stronger stamina recovery.",
      apply: (p) => {
        p.maxStamina += 22;
        p.stamina = p.maxStamina;
        p.staminaRegen += 4;
      }
    },
    {
      id: "crit",
      name: "Red Moon Mark",
      text: "+8% critical chance.",
      apply: (p) => { p.crit = Math.min(0.65, p.crit + 0.08); }
    },
    {
      id: "bulwark",
      name: "Obsidian Guard",
      text: "+9% damage reduction.",
      apply: (p) => { p.armor = Math.min(0.55, p.armor + 0.09); }
    },
    {
      id: "reach",
      name: "Long Night Steel",
      text: "+16 attack range.",
      apply: (p) => { p.range += 16; }
    },
    {
      id: "leech",
      name: "Hunger Rune",
      text: "Recover health from critical hits.",
      apply: (p) => { p.leech += 0.04; }
    },
    {
      id: "arc",
      name: "Wide Rift",
      text: "+18% skill area.",
      apply: (p) => { p.areaBonus *= 1.18; }
    }
  ];

  const state = {
    mode: "menu",
    selectedClass: "knight",
    time: 0,
    lastTime: 0,
    dpr: 1,
    viewW: window.innerWidth,
    viewH: window.innerHeight,
    camera: { x: 0, y: 0, shake: 0 },
    player: null,
    wave: 0,
    waveCleared: false,
    intermission: 0,
    score: 0,
    highScore: Number(localStorage.getItem("abyssRisesBest") || 0),
    muted: false,
    keys: new Set(),
    mouse: { sx: window.innerWidth / 2, sy: window.innerHeight / 2, wx: WORLD.width / 2, wy: WORLD.height / 2, down: false },
    props: [],
    enemies: [],
    projectiles: [],
    drops: [],
    particles: [],
    damageTexts: [],
    slashes: [],
    shockwaves: [],
    telegraphs: [],
    comboHits: 0,
    comboTimer: 0,
    combatPulse: 0,
    flash: 0,
    toastTimer: 0,
    audio: null
  };

  function rand(min, max) {
    return Math.random() * (max - min) + min;
  }

  function randInt(min, max) {
    return Math.floor(rand(min, max + 1));
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function distance(ax, ay, bx, by) {
    return Math.hypot(ax - bx, ay - by);
  }

  function angleTo(ax, ay, bx, by) {
    return Math.atan2(by - ay, bx - ax);
  }

  function angleDelta(a, b) {
    return Math.atan2(Math.sin(a - b), Math.cos(a - b));
  }

  function pick(list) {
    return list[Math.floor(Math.random() * list.length)];
  }

  function seededNoise(seed, index) {
    const value = Math.sin(seed * 9973 + index * 101.37) * 10000;
    return value - Math.floor(value);
  }

  function resize() {
    state.dpr = Math.min(window.devicePixelRatio || 1, 2);
    state.viewW = window.innerWidth;
    state.viewH = window.innerHeight;
    canvas.width = Math.floor(state.viewW * state.dpr);
    canvas.height = Math.floor(state.viewH * state.dpr);
    canvas.style.width = `${state.viewW}px`;
    canvas.style.height = `${state.viewH}px`;
    updateMouseWorld();
    updateCamera(1);
  }

  function updateMouseWorld() {
    state.mouse.wx = state.mouse.sx + state.camera.x;
    state.mouse.wy = state.mouse.sy + state.camera.y;
  }

  function generateArena() {
    state.props = [];
    for (let i = 0; i < 72; i += 1) {
      const x = rand(150, WORLD.width - 150);
      const y = rand(150, WORLD.height - 150);
      if (distance(x, y, WORLD.width / 2, WORLD.height / 2) < 310) continue;
      const roll = Math.random();
      state.props.push({
        type: roll < 0.25 ? "torch" : roll < 0.62 ? "pillar" : roll < 0.82 ? "rubble" : "crack",
        x,
        y,
        r: rand(22, 56),
        rot: rand(0, TAU),
        glow: rand(120, 220),
        seed: Math.random()
      });
    }
  }

  function createPlayer(classId) {
    const hero = HEROES[classId];
    return {
      classId,
      name: hero.name,
      x: WORLD.width / 2,
      y: WORLD.height / 2,
      radius: 18,
      hp: hero.hp,
      maxHp: hero.hp,
      stamina: hero.stamina,
      maxStamina: hero.stamina,
      staminaRegen: 22,
      speed: hero.speed,
      damage: hero.damage,
      range: hero.range,
      crit: hero.crit,
      armor: hero.armor,
      attackSpeed: hero.attackSpeed,
      attackCd: 0,
      attackMax: 0.28 / hero.attackSpeed,
      dashCd: 0,
      dashMax: 1.05,
      dashTime: 0,
      dashVx: 0,
      dashVy: 0,
      skillOneCd: 0,
      skillTwoCd: 0,
      skillOneMax: hero.skillOneCd,
      skillTwoMax: hero.skillTwoCd,
      comboStep: 0,
      comboTimer: 0,
      invuln: 0,
      level: 1,
      xp: 0,
      xpNext: 100,
      levelUps: 0,
      kills: 0,
      gold: 0,
      fury: 0,
      maxFury: 100,
      leech: 0,
      areaBonus: 1,
      color: hero.color,
      accent: hero.accent
    };
  }

  function beginGame() {
    state.player = createPlayer(state.selectedClass);
    state.mode = "playing";
    state.wave = 0;
    state.waveCleared = false;
    state.intermission = 0;
    state.score = 0;
    state.enemies = [];
    state.projectiles = [];
    state.drops = [];
    state.particles = [];
    state.damageTexts = [];
    state.slashes = [];
    state.shockwaves = [];
    state.telegraphs = [];
    state.comboHits = 0;
    state.comboTimer = 0;
    state.combatPulse = 0;
    state.flash = 0;
    state.camera.x = clamp(state.player.x - state.viewW / 2, 0, WORLD.width - state.viewW);
    state.camera.y = clamp(state.player.y - state.viewH / 2, 0, WORLD.height - state.viewH);
    refs.menuOverlay.classList.add("hidden");
    refs.gameOverOverlay.classList.add("hidden");
    refs.levelOverlay.classList.add("hidden");
    refs.pauseButton.classList.remove("is-paused");
    spawnWave();
    updateHUD();
    showToast("The rift opens.");
  }

  function spawnWave() {
    state.wave += 1;
    state.waveCleared = false;
    state.intermission = 0;

    const count = Math.min(28, 4 + state.wave * 2);
    const choices = ["ashbound"];
    if (state.wave >= 2) choices.push("shade");
    if (state.wave >= 3) choices.push("sentinel");
    if (state.wave >= 4) choices.push("seer");

    for (let i = 0; i < count; i += 1) {
      spawnEnemy(pick(choices));
    }

    if (state.wave % 5 === 0) {
      spawnEnemy("boss", true);
      showToast("An Eclipse Champion has entered.");
    } else {
      showToast(`Wave ${state.wave}`);
    }
  }

  function spawnEnemy(typeId, elite = false) {
    const base = ENEMY_TYPES[typeId];
    const side = randInt(0, 3);
    let x;
    let y;
    if (side === 0) {
      x = rand(80, WORLD.width - 80);
      y = 80;
    } else if (side === 1) {
      x = WORLD.width - 80;
      y = rand(80, WORLD.height - 80);
    } else if (side === 2) {
      x = rand(80, WORLD.width - 80);
      y = WORLD.height - 80;
    } else {
      x = 80;
      y = rand(80, WORLD.height - 80);
    }

    const scale = base.boss ? 1 + state.wave * 0.16 : 1 + state.wave * 0.09 + (elite ? 0.25 : 0);
    state.enemies.push({
      id: window.crypto && typeof window.crypto.randomUUID === "function" ? window.crypto.randomUUID() : `${Date.now()}-${Math.random()}`,
      typeId,
      name: base.name,
      x,
      y,
      vx: 0,
      vy: 0,
      hp: base.hp * scale,
      maxHp: base.hp * scale,
      damage: base.damage * (1 + state.wave * 0.045),
      speed: base.speed * (base.boss ? 1 : 1 + state.wave * 0.012),
      radius: base.radius * (elite && !base.boss ? 1.12 : 1),
      reach: base.reach,
      xp: Math.round(base.xp * scale),
      score: Math.round(base.score * scale),
      ranged: Boolean(base.ranged),
      boss: Boolean(base.boss),
      elite,
      color: base.color,
      accent: base.accent,
      attackCd: rand(0.3, 1.2),
      skillCd: base.boss ? 2.2 : 0,
      chargeTime: 0,
      chargeAngle: 0,
      hurt: 0,
      stun: 0,
      dead: false
    });
  }

  function tickCooldowns(p, dt) {
    p.attackCd = Math.max(0, p.attackCd - dt);
    p.dashCd = Math.max(0, p.dashCd - dt);
    p.skillOneCd = Math.max(0, p.skillOneCd - dt);
    p.skillTwoCd = Math.max(0, p.skillTwoCd - dt);
    p.comboTimer = Math.max(0, p.comboTimer - dt);
    p.invuln = Math.max(0, p.invuln - dt);
    p.stamina = Math.min(p.maxStamina, p.stamina + p.staminaRegen * dt);
    if (p.comboTimer <= 0) p.comboStep = 0;
  }

  function updateCombo(dt) {
    if (state.comboTimer > 0) {
      state.comboTimer -= dt;
      if (state.comboTimer <= 0) {
        state.comboHits = 0;
        state.comboTimer = 0;
      }
    }
  }

  function comboRank() {
    if (state.comboHits >= 90) return "SSS";
    if (state.comboHits >= 60) return "SS";
    if (state.comboHits >= 38) return "S";
    if (state.comboHits >= 22) return "A";
    if (state.comboHits >= 10) return "B";
    if (state.comboHits >= 4) return "C";
    return "D";
  }

  function comboMultiplier() {
    return 1 + Math.min(0.75, Math.max(0, state.comboHits - 1) * 0.012);
  }

  function addCombo(weight = 1) {
    state.comboHits += weight;
    state.comboTimer = 3.1;
    state.combatPulse = 0.26;
  }

  function update(dt) {
    const p = state.player;
    if (!p) return;

    state.time += dt;
    tickCooldowns(p, dt);
    updateCombo(dt);
    updateMouseWorld();
    updatePlayerMovement(dt);

    if (state.mouse.down && p.attackCd <= 0) {
      basicAttack();
    }

    updateEnemies(dt);
    updateProjectiles(dt);
    updateDrops(dt);
    updateEffects(dt);
    updateWaves(dt);
    updateCamera(dt);
    updateHUD();
  }

  function updateAmbient(dt) {
    state.time += dt;
    updateEffects(dt);
    updateCamera(dt);
    if (state.toastTimer > 0) {
      state.toastTimer -= dt;
      if (state.toastTimer <= 0) refs.toast.classList.remove("show");
    }
  }

  function updatePlayerMovement(dt) {
    const p = state.player;
    let ix = 0;
    let iy = 0;
    if (state.keys.has("KeyA") || state.keys.has("ArrowLeft")) ix -= 1;
    if (state.keys.has("KeyD") || state.keys.has("ArrowRight")) ix += 1;
    if (state.keys.has("KeyW") || state.keys.has("ArrowUp")) iy -= 1;
    if (state.keys.has("KeyS") || state.keys.has("ArrowDown")) iy += 1;

    const len = Math.hypot(ix, iy) || 1;
    ix /= len;
    iy /= len;

    if (p.dashTime > 0) {
      p.x += p.dashVx * dt;
      p.y += p.dashVy * dt;
      p.dashTime -= dt;
      addParticle(p.x - p.dashVx * 0.025, p.y - p.dashVy * 0.025, p.accent, 0.22, rand(3, 7), rand(24, 80));
    } else {
      p.x += ix * p.speed * dt;
      p.y += iy * p.speed * dt;
    }

    p.x = clamp(p.x, 54, WORLD.width - 54);
    p.y = clamp(p.y, 54, WORLD.height - 54);
  }

  function basicAttack() {
    const p = state.player;
    if (p.attackCd > 0 || p.stamina < 4) return;

    p.stamina -= 4;
    p.attackMax = 0.31 / p.attackSpeed;
    p.attackCd = p.attackMax;
    p.comboStep = p.comboTimer > 0 ? (p.comboStep % 3) + 1 : 1;
    p.comboTimer = 0.78;

    const aim = angleTo(p.x, p.y, state.mouse.wx, state.mouse.wy);
    const comboDamage = [0, 0.86, 1.0, 1.32][p.comboStep];
    const comboArc = [0, 1.32, 1.46, 1.72][p.comboStep];
    const range = p.range + (p.comboStep === 3 ? 18 : 0);
    hitEnemiesCone(p.x, p.y, aim, range, comboArc, p.damage * comboDamage, 260 + p.comboStep * 32, "attack");

    state.slashes.push({
      x: p.x,
      y: p.y,
      angle: aim,
      arc: comboArc,
      range,
      life: 0.18,
      maxLife: 0.18,
      color: p.comboStep === 3 ? p.accent : p.color
    });
    shake(2.8);
    playTone(120 + p.comboStep * 42, 0.045, "sawtooth", 0.022);
  }

  function dash() {
    const p = state.player;
    if (p.dashCd > 0 || p.stamina < 18) return;

    let ix = 0;
    let iy = 0;
    if (state.keys.has("KeyA") || state.keys.has("ArrowLeft")) ix -= 1;
    if (state.keys.has("KeyD") || state.keys.has("ArrowRight")) ix += 1;
    if (state.keys.has("KeyW") || state.keys.has("ArrowUp")) iy -= 1;
    if (state.keys.has("KeyS") || state.keys.has("ArrowDown")) iy += 1;
    if (!ix && !iy) {
      const a = angleTo(p.x, p.y, state.mouse.wx, state.mouse.wy);
      ix = Math.cos(a);
      iy = Math.sin(a);
    }
    const len = Math.hypot(ix, iy) || 1;
    ix /= len;
    iy /= len;

    p.stamina -= 18;
    p.dashCd = p.dashMax;
    p.dashTime = 0.18;
    p.invuln = Math.max(p.invuln, 0.24);
    p.dashVx = ix * 780;
    p.dashVy = iy * 780;
    shake(3.4);
    playTone(240, 0.055, "triangle", 0.035);
  }

  function castSkillOne() {
    const p = state.player;
    if (p.skillOneCd > 0 || p.stamina < 30) return;

    p.stamina -= 30;
    p.skillOneCd = p.skillOneMax;
    const radius = (168 + p.level * 3) * p.areaBonus;
    areaBlast(p.x, p.y, radius, p.damage * 1.65, 420, "skill");
    state.shockwaves.push({
      owner: "player",
      x: p.x,
      y: p.y,
      radius,
      life: 0.42,
      maxLife: 0.42,
      age: 0,
      color: p.color
    });
    for (let i = 0; i < 34; i += 1) {
      const a = rand(0, TAU);
      addParticle(p.x + Math.cos(a) * rand(8, 46), p.y + Math.sin(a) * rand(8, 46), Math.random() > 0.5 ? p.color : p.accent, rand(0.26, 0.48), rand(4, 10), rand(110, 240), a);
    }
    shake(7);
    playTone(96, 0.14, "sawtooth", 0.04);
    showToast(HEROES[p.classId].skillOne);
  }

  function castSkillTwo() {
    const p = state.player;
    if (p.skillTwoCd > 0 || p.stamina < 34) return;

    p.stamina -= 34;
    p.skillTwoCd = p.skillTwoMax;
    const a = angleTo(p.x, p.y, state.mouse.wx, state.mouse.wy);
    state.projectiles.push({
      owner: "player",
      x: p.x + Math.cos(a) * 28,
      y: p.y + Math.sin(a) * 28,
      vx: Math.cos(a) * 820,
      vy: Math.sin(a) * 820,
      radius: 13,
      life: 0.8,
      damage: p.damage * 2.05,
      pierce: 5,
      hit: new Set(),
      color: p.accent,
      trail: []
    });
    state.slashes.push({
      x: p.x,
      y: p.y,
      angle: a,
      arc: 0.38,
      range: 220,
      life: 0.22,
      maxLife: 0.22,
      color: p.accent
    });
    shake(5);
    playTone(420, 0.08, "square", 0.026);
    showToast(HEROES[p.classId].skillTwo);
  }

  function castUltimate() {
    const p = state.player;
    if (!p || p.fury < p.maxFury) {
      showToast("Fury is not ready");
      return;
    }

    p.fury = 0;
    p.invuln = Math.max(p.invuln, 1.35);
    p.stamina = p.maxStamina;
    p.hp = Math.min(p.maxHp, p.hp + p.maxHp * 0.18);
    state.flash = 0.48;

    const radius = 520 * p.areaBonus;
    areaBlast(p.x, p.y, radius, p.damage * 4.8, 980, "ultimate");
    addDamageText(p.x, p.y - 66, "AWAKEN", "#f6dfae", true);

    for (let i = 0; i < 3; i += 1) {
      state.shockwaves.push({
        owner: "player",
        x: p.x,
        y: p.y,
        radius: radius * (0.45 + i * 0.24),
        life: 0.6 + i * 0.12,
        maxLife: 0.6 + i * 0.12,
        age: 0,
        color: i % 2 ? p.accent : "#f6dfae"
      });
    }

    for (let i = 0; i < 9; i += 1) {
      state.slashes.push({
        x: p.x,
        y: p.y,
        angle: (i / 9) * TAU + state.time * 0.5,
        arc: 0.46,
        range: radius * rand(0.38, 0.9),
        life: 0.38 + i * 0.015,
        maxLife: 0.38 + i * 0.015,
        color: i % 2 ? p.color : p.accent
      });
    }

    for (let i = 0; i < 90; i += 1) {
      const a = rand(0, TAU);
      const start = rand(12, 110);
      addParticle(p.x + Math.cos(a) * start, p.y + Math.sin(a) * start, Math.random() > 0.5 ? "#f6dfae" : p.accent, rand(0.42, 0.9), rand(4, 12), rand(220, 520), a);
    }

    shake(20);
    playTone(58, 0.22, "sawtooth", 0.052);
    window.setTimeout(() => playTone(116, 0.18, "triangle", 0.032), 90);
    showToast("Abyss Awakening");
  }

  function hitEnemiesCone(x, y, angle, range, arc, damage, force, source) {
    for (const enemy of state.enemies) {
      if (enemy.dead) continue;
      const d = distance(x, y, enemy.x, enemy.y);
      if (d > range + enemy.radius) continue;
      const toEnemy = angleTo(x, y, enemy.x, enemy.y);
      if (Math.abs(angleDelta(toEnemy, angle)) > arc / 2) continue;
      const falloff = 1 - Math.max(0, d - 40) / Math.max(range, 1) * 0.22;
      const knockAngle = angleTo(x, y, enemy.x, enemy.y);
      damageEnemy(enemy, damage * falloff, Math.cos(knockAngle) * force, Math.sin(knockAngle) * force, source);
    }
  }

  function areaBlast(x, y, radius, damage, force, source) {
    for (const enemy of state.enemies) {
      if (enemy.dead) continue;
      const d = distance(x, y, enemy.x, enemy.y);
      if (d > radius + enemy.radius) continue;
      const pct = 1 - d / Math.max(radius, 1);
      const a = angleTo(x, y, enemy.x, enemy.y);
      damageEnemy(enemy, damage * (0.72 + pct * 0.42), Math.cos(a) * force * (0.6 + pct), Math.sin(a) * force * (0.6 + pct), source);
    }
  }

  function damageEnemy(enemy, amount, kx, ky, source) {
    const p = state.player;
    const crit = Math.random() < p.crit + (source === "skill" ? 0.04 : 0);
    const finalDamage = Math.max(1, amount * (crit ? 1.75 : 1) * rand(0.92, 1.08));
    enemy.hp -= finalDamage;
    addCombo(crit ? 2 : 1);
    if (source !== "ultimate") {
      p.fury = Math.min(p.maxFury, p.fury + (crit ? 2.8 : 1.1) + finalDamage * 0.012);
    }
    enemy.vx += kx / Math.max(enemy.radius * 11, 1);
    enemy.vy += ky / Math.max(enemy.radius * 11, 1);
    enemy.stun = Math.max(enemy.stun, source === "skill" ? 0.18 : 0.08);
    enemy.hurt = 0.16;
    addDamageText(enemy.x, enemy.y - enemy.radius - 12, Math.round(finalDamage), crit ? "#f6dfae" : "#ffffff", crit);
    burst(enemy.x, enemy.y, crit ? "#f6dfae" : enemy.accent, crit ? 12 : 7, crit ? 210 : 150);
    if (crit && p.leech > 0) {
      p.hp = Math.min(p.maxHp, p.hp + finalDamage * p.leech);
    }
    if (enemy.hp <= 0 && !enemy.dead) {
      killEnemy(enemy);
    }
  }

  function damagePlayer(amount, ax, ay) {
    const p = state.player;
    if (!p || p.invuln > 0 || state.mode !== "playing") return;
    const reduced = Math.max(1, amount * (1 - p.armor));
    p.hp -= reduced;
    p.invuln = 0.45;
    shake(8);
    burst(p.x, p.y, "#d84a3d", 15, 210);
    addDamageText(p.x, p.y - 36, Math.round(reduced), "#e64d56", false);
    if (ax || ay) {
      p.x += ax * 14;
      p.y += ay * 14;
    }
    playTone(70, 0.12, "sawtooth", 0.035);
    if (p.hp <= 0) {
      endGame(false);
    }
  }

  function killEnemy(enemy) {
    const p = state.player;
    enemy.dead = true;
    p.kills += 1;
    state.score += Math.round(enemy.score * comboMultiplier());
    p.fury = Math.min(p.maxFury, p.fury + (enemy.boss ? 38 : 8));
    grantXp(enemy.xp);
    burst(enemy.x, enemy.y, enemy.boss ? "#d8a95a" : enemy.accent, enemy.boss ? 46 : 22, enemy.boss ? 330 : 220);
    shake(enemy.boss ? 12 : 4);

    if (enemy.boss || Math.random() < 0.22) {
      state.drops.push({ type: "health", x: enemy.x + rand(-18, 18), y: enemy.y + rand(-18, 18), value: 22 + state.wave * 2, vx: rand(-40, 40), vy: rand(-40, 40), radius: 10, life: 14 });
    }
    if (Math.random() < 0.34) {
      state.drops.push({ type: "gold", x: enemy.x + rand(-24, 24), y: enemy.y + rand(-24, 24), value: randInt(3, 9 + state.wave), vx: rand(-60, 60), vy: rand(-60, 60), radius: 8, life: 16 });
    }
    if (Math.random() < 0.18) {
      state.drops.push({ type: "stamina", x: enemy.x + rand(-16, 16), y: enemy.y + rand(-16, 16), value: 24, vx: rand(-45, 45), vy: rand(-45, 45), radius: 9, life: 13 });
    }
  }

  function grantXp(amount) {
    const p = state.player;
    p.xp += amount;
    while (p.xp >= p.xpNext) {
      p.xp -= p.xpNext;
      p.level += 1;
      p.levelUps += 1;
      p.xpNext = Math.round(p.xpNext * 1.28 + 34);
      p.maxHp += 8;
      p.hp = Math.min(p.maxHp, p.hp + 28);
      p.damage *= 1.035;
    }
    if (p.levelUps > 0 && state.mode === "playing") {
      showLevelUp();
    }
  }

  function showLevelUp() {
    const p = state.player;
    state.mode = "levelup";
    refs.levelOverlay.classList.remove("hidden");
    refs.upgradeCards.replaceChildren();

    const pool = [...UPGRADE_POOL].sort(() => Math.random() - 0.5).slice(0, 3);
    for (const upgrade of pool) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "upgrade-card";
      button.innerHTML = `<strong>${upgrade.name}</strong><span>${upgrade.text}</span>`;
      button.addEventListener("click", () => {
        upgrade.apply(p);
        p.levelUps = Math.max(0, p.levelUps - 1);
        refs.levelOverlay.classList.add("hidden");
        state.mode = "playing";
        showToast(upgrade.name);
        updateHUD();
        if (p.levelUps > 0) {
          window.setTimeout(showLevelUp, 80);
        }
      });
      refs.upgradeCards.appendChild(button);
    }
  }

  function updateEnemies(dt) {
    const p = state.player;
    for (const enemy of state.enemies) {
      if (enemy.dead) continue;
      enemy.attackCd = Math.max(0, enemy.attackCd - dt);
      enemy.skillCd = Math.max(0, enemy.skillCd - dt);
      enemy.hurt = Math.max(0, enemy.hurt - dt);

      if (enemy.boss) {
        updateBoss(enemy, dt);
      } else {
        updateEnemy(enemy, dt);
      }

      enemy.x += enemy.vx * dt;
      enemy.y += enemy.vy * dt;
      enemy.vx *= Math.pow(0.04, dt);
      enemy.vy *= Math.pow(0.04, dt);
      enemy.x = clamp(enemy.x, 48, WORLD.width - 48);
      enemy.y = clamp(enemy.y, 48, WORLD.height - 48);

      if (distance(enemy.x, enemy.y, p.x, p.y) < enemy.radius + p.radius - 2 && enemy.attackCd <= 0.25) {
        const a = angleTo(enemy.x, enemy.y, p.x, p.y);
        damagePlayer(enemy.damage * 0.52, Math.cos(a), Math.sin(a));
        enemy.attackCd = Math.max(enemy.attackCd, 0.7);
      }
    }

    separateEnemies();
    state.enemies = state.enemies.filter((enemy) => !enemy.dead);
  }

  function updateEnemy(enemy, dt) {
    const p = state.player;
    const d = distance(enemy.x, enemy.y, p.x, p.y);
    const a = angleTo(enemy.x, enemy.y, p.x, p.y);

    if (enemy.stun > 0) {
      enemy.stun -= dt;
      return;
    }

    if (enemy.ranged && d < 540 && enemy.attackCd <= 0) {
      enemy.attackCd = rand(1.4, 2.15);
      enemyCast(enemy, a);
      return;
    }

    if (d > enemy.radius + p.radius + enemy.reach) {
      enemy.vx += Math.cos(a) * enemy.speed * 4.2 * dt;
      enemy.vy += Math.sin(a) * enemy.speed * 4.2 * dt;
    } else if (enemy.attackCd <= 0) {
      enemy.attackCd = rand(0.92, 1.28);
      damagePlayer(enemy.damage, Math.cos(a), Math.sin(a));
      state.slashes.push({
        x: enemy.x,
        y: enemy.y,
        angle: a,
        arc: 1.35,
        range: enemy.radius + enemy.reach + 28,
        life: 0.16,
        maxLife: 0.16,
        color: enemy.accent
      });
    }
  }

  function updateBoss(enemy, dt) {
    const p = state.player;
    const d = distance(enemy.x, enemy.y, p.x, p.y);
    const a = angleTo(enemy.x, enemy.y, p.x, p.y);

    if (enemy.chargeTime > 0) {
      enemy.chargeTime -= dt;
      enemy.vx += Math.cos(enemy.chargeAngle) * 720 * dt;
      enemy.vy += Math.sin(enemy.chargeAngle) * 720 * dt;
      if (d < enemy.radius + p.radius + 8) {
        damagePlayer(enemy.damage * 1.35, Math.cos(enemy.chargeAngle), Math.sin(enemy.chargeAngle));
      }
      return;
    }

    if (enemy.skillCd <= 0) {
      if (Math.random() < 0.55) {
        enemy.skillCd = 4.3;
        enemy.chargeTime = 0.58;
        enemy.chargeAngle = a;
        state.telegraphs.push({
          type: "line",
          x: enemy.x,
          y: enemy.y,
          angle: a,
          length: 680,
          width: 96,
          life: 0.58,
          maxLife: 0.58,
          color: "#d84a3d"
        });
        showToast("Champion charge");
      } else {
        enemy.skillCd = 5.1;
        enemyShockwave(enemy);
      }
    }

    if (d > enemy.radius + p.radius + enemy.reach) {
      enemy.vx += Math.cos(a) * enemy.speed * 3.2 * dt;
      enemy.vy += Math.sin(a) * enemy.speed * 3.2 * dt;
    } else if (enemy.attackCd <= 0) {
      enemy.attackCd = 1.15;
      damagePlayer(enemy.damage * 1.15, Math.cos(a), Math.sin(a));
      state.slashes.push({
        x: enemy.x,
        y: enemy.y,
        angle: a,
        arc: 1.8,
        range: enemy.radius + enemy.reach + 42,
        life: 0.22,
        maxLife: 0.22,
        color: enemy.accent
      });
    }
  }

  function separateEnemies() {
    for (let i = 0; i < state.enemies.length; i += 1) {
      const a = state.enemies[i];
      for (let j = i + 1; j < state.enemies.length; j += 1) {
        const b = state.enemies[j];
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const d = Math.hypot(dx, dy) || 1;
        const min = a.radius + b.radius + 3;
        if (d < min) {
          const push = (min - d) * 0.5;
          const nx = dx / d;
          const ny = dy / d;
          a.x -= nx * push;
          a.y -= ny * push;
          b.x += nx * push;
          b.y += ny * push;
        }
      }
    }
  }

  function enemyCast(enemy, angle) {
    state.telegraphs.push({
      type: "line",
      x: enemy.x,
      y: enemy.y,
      angle,
      length: 380,
      width: 34,
      life: 0.26,
      maxLife: 0.26,
      color: enemy.accent
    });
    state.projectiles.push({
      owner: "enemy",
      x: enemy.x + Math.cos(angle) * (enemy.radius + 8),
      y: enemy.y + Math.sin(angle) * (enemy.radius + 8),
      vx: Math.cos(angle) * 330,
      vy: Math.sin(angle) * 330,
      radius: 10,
      life: 2.2,
      damage: enemy.damage,
      color: enemy.accent,
      trail: []
    });
    playTone(185, 0.05, "triangle", 0.018);
  }

  function enemyShockwave(enemy) {
    state.telegraphs.push({
      type: "ring",
      x: enemy.x,
      y: enemy.y,
      radius: 310,
      life: 0.72,
      maxLife: 0.72,
      color: enemy.accent
    });
    state.shockwaves.push({
      owner: "enemy",
      x: enemy.x,
      y: enemy.y,
      radius: 310,
      life: 0.95,
      maxLife: 0.95,
      age: 0,
      hitPlayer: false,
      damage: enemy.damage * 1.15,
      color: enemy.accent
    });
    showToast("Eclipse shockwave");
    shake(9);
  }

  function updateProjectiles(dt) {
    const p = state.player;
    for (const pr of state.projectiles) {
      pr.life -= dt;
      pr.trail.push({ x: pr.x, y: pr.y, life: 0.24 });
      if (pr.trail.length > 9) pr.trail.shift();
      pr.x += pr.vx * dt;
      pr.y += pr.vy * dt;

      if (pr.owner === "enemy") {
        if (distance(pr.x, pr.y, p.x, p.y) < pr.radius + p.radius) {
          const a = angleTo(pr.x, pr.y, p.x, p.y);
          damagePlayer(pr.damage, Math.cos(a), Math.sin(a));
          pr.life = 0;
        }
      } else {
        for (const enemy of state.enemies) {
          if (enemy.dead || pr.hit.has(enemy.id)) continue;
          if (distance(pr.x, pr.y, enemy.x, enemy.y) < pr.radius + enemy.radius) {
            pr.hit.add(enemy.id);
            damageEnemy(enemy, pr.damage, pr.vx * 0.2, pr.vy * 0.2, "skill");
            pr.pierce -= 1;
            if (pr.pierce <= 0) {
              pr.life = 0;
              break;
            }
          }
        }
      }
    }
    state.projectiles = state.projectiles.filter((pr) => pr.life > 0 && pr.x > 0 && pr.y > 0 && pr.x < WORLD.width && pr.y < WORLD.height);
  }

  function updateDrops(dt) {
    const p = state.player;
    for (const drop of state.drops) {
      drop.life -= dt;
      drop.x += drop.vx * dt;
      drop.y += drop.vy * dt;
      drop.vx *= Math.pow(0.02, dt);
      drop.vy *= Math.pow(0.02, dt);

      const d = distance(drop.x, drop.y, p.x, p.y);
      if (d < 170) {
        const a = angleTo(drop.x, drop.y, p.x, p.y);
        drop.vx += Math.cos(a) * 620 * dt;
        drop.vy += Math.sin(a) * 620 * dt;
      }
      if (d < p.radius + drop.radius + 5) {
        collectDrop(drop);
        drop.life = 0;
      }
    }
    state.drops = state.drops.filter((drop) => drop.life > 0);
  }

  function collectDrop(drop) {
    const p = state.player;
    if (drop.type === "health") {
      p.hp = Math.min(p.maxHp, p.hp + drop.value);
      addDamageText(p.x, p.y - 42, `+${Math.round(drop.value)}`, "#4ec09a", false);
      playTone(310, 0.06, "triangle", 0.018);
    } else if (drop.type === "stamina") {
      p.stamina = Math.min(p.maxStamina, p.stamina + drop.value);
      addDamageText(p.x, p.y - 42, `+${Math.round(drop.value)}`, "#9b72e2", false);
      playTone(380, 0.06, "triangle", 0.018);
    } else {
      p.gold += drop.value;
      state.score += drop.value * 5;
      addDamageText(p.x, p.y - 42, `+${drop.value}`, "#d8a95a", false);
      playTone(520, 0.04, "square", 0.015);
    }
  }

  function updateEffects(dt) {
    for (const particle of state.particles) {
      particle.life -= dt;
      particle.x += particle.vx * dt;
      particle.y += particle.vy * dt;
      particle.vx *= Math.pow(0.08, dt);
      particle.vy *= Math.pow(0.08, dt);
    }
    state.particles = state.particles.filter((particle) => particle.life > 0);

    for (const text of state.damageTexts) {
      text.life -= dt;
      text.y -= 42 * dt;
      text.x += text.vx * dt;
    }
    state.damageTexts = state.damageTexts.filter((text) => text.life > 0);

    for (const slash of state.slashes) {
      slash.life -= dt;
    }
    state.slashes = state.slashes.filter((slash) => slash.life > 0);

    for (const wave of state.shockwaves) {
      wave.life -= dt;
      wave.age += dt;
      if (wave.owner === "enemy" && !wave.hitPlayer && state.player) {
        const progress = clamp(wave.age / wave.maxLife, 0, 1);
        const currentRadius = wave.radius * progress;
        const d = distance(wave.x, wave.y, state.player.x, state.player.y);
        if (Math.abs(d - currentRadius) < 24 + state.player.radius) {
          const a = angleTo(wave.x, wave.y, state.player.x, state.player.y);
          damagePlayer(wave.damage, Math.cos(a), Math.sin(a));
          wave.hitPlayer = true;
        }
      }
    }
    state.shockwaves = state.shockwaves.filter((wave) => wave.life > 0);

    for (const telegraph of state.telegraphs) {
      telegraph.life -= dt;
    }
    state.telegraphs = state.telegraphs.filter((telegraph) => telegraph.life > 0);

    state.camera.shake = Math.max(0, state.camera.shake - 36 * dt);
    state.combatPulse = Math.max(0, state.combatPulse - dt);
    state.flash = Math.max(0, state.flash - dt);
    if (state.toastTimer > 0) {
      state.toastTimer -= dt;
      if (state.toastTimer <= 0) refs.toast.classList.remove("show");
    }
  }

  function updateWaves(dt) {
    if (state.enemies.length === 0 && !state.waveCleared) {
      state.waveCleared = true;
      state.intermission = 3.5;
      const p = state.player;
      p.hp = Math.min(p.maxHp, p.hp + 18);
      p.stamina = p.maxStamina;
      showToast(`Wave ${state.wave} cleared`);
    }
    if (state.waveCleared) {
      state.intermission -= dt;
      if (state.intermission <= 0) {
        spawnWave();
      }
    }
  }

  function updateCamera(dt) {
    const target = state.player || { x: WORLD.width / 2, y: WORLD.height / 2 };
    const maxX = Math.max(0, WORLD.width - state.viewW);
    const maxY = Math.max(0, WORLD.height - state.viewH);
    const tx = clamp(target.x - state.viewW * 0.5, 0, maxX);
    const ty = clamp(target.y - state.viewH * 0.5, 0, maxY);
    const rate = state.player ? 1 - Math.pow(0.0005, dt) : 1;
    state.camera.x += (tx - state.camera.x) * rate;
    state.camera.y += (ty - state.camera.y) * rate;
  }

  function updateHUD() {
    const p = state.player;
    if (!p) return;
    refs.className.textContent = p.name;
    refs.levelText.textContent = `Lv ${p.level}`;
    refs.hpBar.style.width = `${clamp((p.hp / p.maxHp) * 100, 0, 100)}%`;
    refs.hpText.textContent = `${Math.max(0, Math.round(p.hp))} / ${Math.round(p.maxHp)}`;
    refs.staminaBar.style.width = `${clamp((p.stamina / p.maxStamina) * 100, 0, 100)}%`;
    refs.staminaText.textContent = `${Math.round(p.stamina)} / ${Math.round(p.maxStamina)}`;
    refs.xpBar.style.width = `${clamp((p.xp / p.xpNext) * 100, 0, 100)}%`;
    refs.waveText.textContent = state.wave;
    refs.scoreText.textContent = state.score;
    refs.goldText.textContent = p.gold;
    refs.comboText.textContent = state.comboHits > 0 ? `${state.comboHits} Hit` : "0 Hit";
    refs.rankText.textContent = comboRank();
    refs.furyBar.style.width = `${clamp((p.fury / p.maxFury) * 100, 0, 100)}%`;
    refs.furyText.textContent = `${Math.round((p.fury / p.maxFury) * 100)}%`;
    refs.skillOneButton.title = HEROES[p.classId].skillOne;
    refs.skillTwoButton.title = HEROES[p.classId].skillTwo;
    refs.ultimateButton.title = "Abyss Awakening";
    refs.skillOneButton.setAttribute("aria-label", HEROES[p.classId].skillOne);
    refs.skillTwoButton.setAttribute("aria-label", HEROES[p.classId].skillTwo);
    refs.ultimateButton.setAttribute("aria-label", "Abyss Awakening");
    setCooldown(refs.attackButton, p.attackCd, p.attackMax);
    setCooldown(refs.dashButton, p.dashCd, p.dashMax);
    setCooldown(refs.skillOneButton, p.skillOneCd, p.skillOneMax);
    setCooldown(refs.skillTwoButton, p.skillTwoCd, p.skillTwoMax);
    setCharge(refs.ultimateButton, p.fury, p.maxFury);
  }

  function setCooldown(button, value, max) {
    const fill = button.querySelector(".cooldown-fill");
    const pct = max > 0 ? clamp(value / max, 0, 1) : 0;
    fill.style.height = `${pct * 100}%`;
    button.classList.toggle("ready", pct === 0);
  }

  function setCharge(button, value, max) {
    const fill = button.querySelector(".cooldown-fill");
    const pct = max > 0 ? clamp(value / max, 0, 1) : 0;
    fill.style.height = `${(1 - pct) * 100}%`;
    button.classList.toggle("ready", pct >= 1);
    button.classList.toggle("is-empty", pct < 1);
  }

  function showToast(message) {
    refs.toast.textContent = message;
    refs.toast.classList.add("show");
    state.toastTimer = 1.8;
  }

  function endGame(victory) {
    state.mode = "gameover";
    state.mouse.down = false;
    refs.gameOverOverlay.classList.remove("hidden");
    refs.runTitle.textContent = victory ? "Rift Broken" : "Fallen In The Rift";
    refs.finalWave.textContent = state.wave;
    refs.finalScore.textContent = state.score;
    if (state.score > state.highScore) {
      state.highScore = state.score;
      localStorage.setItem("abyssRisesBest", String(state.highScore));
    }
    refs.bestScore.textContent = state.highScore;
    refs.pauseButton.classList.remove("is-paused");
  }

  function togglePause() {
    if (state.mode === "playing") {
      state.mode = "paused";
      state.mouse.down = false;
      refs.pauseButton.classList.add("is-paused");
      showToast("Paused");
    } else if (state.mode === "paused") {
      state.mode = "playing";
      refs.pauseButton.classList.remove("is-paused");
      showToast("Fight resumed");
    }
  }

  function shake(amount) {
    state.camera.shake = Math.max(state.camera.shake, amount);
  }

  function addParticle(x, y, color, life, size, speed, angle = rand(0, TAU)) {
    state.particles.push({
      x,
      y,
      vx: Math.cos(angle) * speed * rand(0.45, 1),
      vy: Math.sin(angle) * speed * rand(0.45, 1),
      life,
      maxLife: life,
      size,
      color
    });
  }

  function burst(x, y, color, count, speed) {
    for (let i = 0; i < count; i += 1) {
      addParticle(x, y, color, rand(0.22, 0.54), rand(2, 7), rand(speed * 0.4, speed));
    }
  }

  function addDamageText(x, y, value, color, crit) {
    state.damageTexts.push({
      x,
      y,
      vx: rand(-18, 18),
      value,
      color,
      crit,
      life: crit ? 0.9 : 0.72,
      maxLife: crit ? 0.9 : 0.72
    });
  }

  function playTone(freq, duration, type, volume) {
    if (state.muted) return;
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;
    if (!state.audio) state.audio = new AudioContext();
    const now = state.audio.currentTime;
    const osc = state.audio.createOscillator();
    const gain = state.audio.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    osc.frequency.exponentialRampToValueAtTime(Math.max(24, freq * 0.58), now + duration);
    gain.gain.setValueAtTime(volume, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    osc.connect(gain);
    gain.connect(state.audio.destination);
    osc.start(now);
    osc.stop(now + duration + 0.02);
  }

  function draw() {
    ctx.setTransform(state.dpr, 0, 0, state.dpr, 0, 0);
    ctx.clearRect(0, 0, state.viewW, state.viewH);
    ctx.fillStyle = "#0d0b0a";
    ctx.fillRect(0, 0, state.viewW, state.viewH);

    const shakeX = state.camera.shake ? rand(-state.camera.shake, state.camera.shake) : 0;
    const shakeY = state.camera.shake ? rand(-state.camera.shake, state.camera.shake) : 0;
    ctx.save();
    ctx.translate(-state.camera.x + shakeX, -state.camera.y + shakeY);
    drawGround();
    drawPropGlows();
    drawDrops();
    drawTelegraphs();
    drawProjectiles();
    drawActors();
    drawSlashes();
    drawShockwaves();
    drawParticles();
    drawDamageTexts();
    ctx.restore();
    drawScreenEffects();
  }

  function drawGround() {
    const cam = state.camera;
    const pad = 140;
    ctx.fillStyle = "#15110f";
    ctx.fillRect(cam.x - pad, cam.y - pad, state.viewW + pad * 2, state.viewH + pad * 2);

    const tile = 112;
    const startX = Math.floor((cam.x - pad) / tile) * tile;
    const startY = Math.floor((cam.y - pad) / tile) * tile;
    for (let x = startX; x < cam.x + state.viewW + pad; x += tile) {
      for (let y = startY; y < cam.y + state.viewH + pad; y += tile) {
        const parity = (Math.floor(x / tile) + Math.floor(y / tile)) % 2;
        ctx.fillStyle = parity ? "rgba(255,255,255,0.018)" : "rgba(0,0,0,0.05)";
        ctx.fillRect(x, y, tile, tile);
        ctx.strokeStyle = "rgba(216,169,90,0.055)";
        ctx.lineWidth = 1;
        ctx.strokeRect(x + 0.5, y + 0.5, tile, tile);
      }
    }

    ctx.lineWidth = 16;
    ctx.strokeStyle = "rgba(216,169,90,0.20)";
    ctx.strokeRect(38, 38, WORLD.width - 76, WORLD.height - 76);
    ctx.lineWidth = 3;
    ctx.strokeStyle = "rgba(216,74,61,0.24)";
    ctx.strokeRect(64, 64, WORLD.width - 128, WORLD.height - 128);
    drawArenaSigil();

    for (const prop of state.props) {
      if (!isNearView(prop.x, prop.y, 240)) continue;
      if (prop.type === "crack") drawCrack(prop);
    }
  }

  function drawArenaSigil() {
    const x = WORLD.width / 2;
    const y = WORLD.height / 2;
    if (!isNearView(x, y, 760)) return;

    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(state.time * 0.05);
    ctx.globalCompositeOperation = "lighter";

    const glow = ctx.createRadialGradient(0, 0, 40, 0, 0, 520);
    glow.addColorStop(0, "rgba(216,74,61,0.12)");
    glow.addColorStop(0.45, "rgba(155,114,226,0.07)");
    glow.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(0, 0, 520, 0, TAU);
    ctx.fill();

    ctx.lineWidth = 3;
    ctx.strokeStyle = "rgba(216,169,90,0.22)";
    for (let r = 150; r <= 430; r += 70) {
      ctx.beginPath();
      ctx.arc(0, 0, r, 0, TAU);
      ctx.stroke();
    }

    ctx.strokeStyle = "rgba(216,74,61,0.20)";
    ctx.lineWidth = 2;
    for (let i = 0; i < 12; i += 1) {
      const a = (i / 12) * TAU;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * 105, Math.sin(a) * 105);
      ctx.lineTo(Math.cos(a) * 460, Math.sin(a) * 460);
      ctx.stroke();
    }

    ctx.restore();
  }

  function drawPropGlows() {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (const prop of state.props) {
      if (prop.type !== "torch" || !isNearView(prop.x, prop.y, prop.glow + 60)) continue;
      const glow = ctx.createRadialGradient(prop.x, prop.y, 0, prop.x, prop.y, prop.glow);
      glow.addColorStop(0, "rgba(241,125,63,0.23)");
      glow.addColorStop(0.45, "rgba(216,74,61,0.08)");
      glow.addColorStop(1, "rgba(216,74,61,0)");
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(prop.x, prop.y, prop.glow, 0, TAU);
      ctx.fill();
    }
    ctx.restore();

    for (const prop of state.props) {
      if (!isNearView(prop.x, prop.y, 160)) continue;
      drawProp(prop);
    }
  }

  function drawProp(prop) {
    ctx.save();
    ctx.translate(prop.x, prop.y);
    ctx.rotate(prop.rot);
    if (prop.type === "pillar") {
      ctx.fillStyle = "rgba(0,0,0,0.28)";
      ellipse(0, prop.r * 0.4, prop.r * 0.78, prop.r * 0.32);
      ctx.fillStyle = "#28221f";
      roundRect(-prop.r * 0.38, -prop.r * 0.72, prop.r * 0.76, prop.r * 1.34, 6, true);
      ctx.strokeStyle = "rgba(216,169,90,0.18)";
      ctx.lineWidth = 2;
      ctx.strokeRect(-prop.r * 0.34, -prop.r * 0.66, prop.r * 0.68, prop.r * 1.2);
      ctx.fillStyle = "rgba(255,255,255,0.06)";
      ctx.fillRect(-prop.r * 0.16, -prop.r * 0.62, prop.r * 0.12, prop.r * 1.1);
    } else if (prop.type === "torch") {
      ctx.fillStyle = "rgba(0,0,0,0.28)";
      ellipse(0, 18, 20, 8);
      ctx.fillStyle = "#3b2920";
      roundRect(-5, -10, 10, 34, 4, true);
      ctx.fillStyle = "#f17d3f";
      ctx.beginPath();
      ctx.moveTo(0, -34);
      ctx.bezierCurveTo(18, -16, 8, -4, 0, 1);
      ctx.bezierCurveTo(-12, -8, -14, -19, 0, -34);
      ctx.fill();
      ctx.fillStyle = "#f6dfae";
      ctx.beginPath();
      ctx.arc(0, -13, 7, 0, TAU);
      ctx.fill();
    } else if (prop.type === "rubble") {
      ctx.fillStyle = "rgba(0,0,0,0.20)";
      ellipse(0, 5, prop.r, prop.r * 0.35);
      for (let i = 0; i < 5; i += 1) {
        ctx.save();
        ctx.rotate((i / 5) * TAU + prop.seed * TAU);
        ctx.translate((seededNoise(prop.seed, i) - 0.5) * prop.r * 0.8, (seededNoise(prop.seed, i + 17) - 0.5) * prop.r * 0.34);
        ctx.fillStyle = i % 2 ? "#29231f" : "#1f1a18";
        roundRect(-prop.r * 0.18, -prop.r * 0.12, prop.r * 0.32, prop.r * 0.2, 3, true);
        ctx.restore();
      }
    }
    ctx.restore();
  }

  function drawCrack(prop) {
    ctx.save();
    ctx.translate(prop.x, prop.y);
    ctx.rotate(prop.rot);
    ctx.strokeStyle = "rgba(0,0,0,0.32)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(-prop.r, 0);
    for (let i = 0; i < 5; i += 1) {
      ctx.lineTo(-prop.r + (prop.r * 2 * i) / 4, Math.sin(i + prop.seed * 5) * prop.r * 0.18);
    }
    ctx.stroke();
    ctx.restore();
  }

  function drawDrops() {
    for (const drop of state.drops) {
      if (!isNearView(drop.x, drop.y, 120)) continue;
      const color = drop.type === "health" ? "#4ec09a" : drop.type === "stamina" ? "#9b72e2" : "#d8a95a";
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.fillStyle = color;
      ctx.globalAlpha = clamp(drop.life / 3, 0.35, 1);
      ctx.beginPath();
      ctx.arc(drop.x, drop.y, drop.radius, 0, TAU);
      ctx.fill();
      ctx.globalAlpha *= 0.26;
      ctx.beginPath();
      ctx.arc(drop.x, drop.y, drop.radius * 3, 0, TAU);
      ctx.fill();
      ctx.restore();
    }
  }

  function drawTelegraphs() {
    for (const telegraph of state.telegraphs) {
      const t = clamp(telegraph.life / telegraph.maxLife, 0, 1);
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = 0.2 + t * 0.35;
      ctx.fillStyle = telegraph.color;
      ctx.strokeStyle = telegraph.color;
      if (telegraph.type === "line") {
        ctx.translate(telegraph.x, telegraph.y);
        ctx.rotate(telegraph.angle);
        const width = telegraph.width * (0.75 + Math.sin(state.time * 18) * 0.08);
        ctx.beginPath();
        ctx.moveTo(0, -width * 0.5);
        ctx.lineTo(telegraph.length, -width * 0.12);
        ctx.lineTo(telegraph.length, width * 0.12);
        ctx.lineTo(0, width * 0.5);
        ctx.closePath();
        ctx.fill();
        ctx.globalAlpha = 0.72;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(telegraph.length, 0);
        ctx.stroke();
      } else {
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.arc(telegraph.x, telegraph.y, telegraph.radius, 0, TAU);
        ctx.stroke();
        ctx.globalAlpha = 0.12 + t * 0.18;
        ctx.beginPath();
        ctx.arc(telegraph.x, telegraph.y, telegraph.radius, 0, TAU);
        ctx.fill();
      }
      ctx.restore();
    }
  }

  function drawProjectiles() {
    for (const pr of state.projectiles) {
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      for (let i = 0; i < pr.trail.length; i += 1) {
        const t = pr.trail[i];
        const alpha = (i + 1) / pr.trail.length * 0.28;
        ctx.globalAlpha = alpha;
        ctx.fillStyle = pr.color;
        ctx.beginPath();
        ctx.arc(t.x, t.y, pr.radius * (0.5 + alpha), 0, TAU);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
      ctx.fillStyle = pr.color;
      ctx.beginPath();
      ctx.arc(pr.x, pr.y, pr.radius, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "#ffffff";
      ctx.globalAlpha = 0.6;
      ctx.beginPath();
      ctx.arc(pr.x - pr.vx * 0.006, pr.y - pr.vy * 0.006, pr.radius * 0.38, 0, TAU);
      ctx.fill();
      ctx.restore();
    }
  }

  function drawActors() {
    const actors = [...state.enemies];
    if (state.player) actors.push(state.player);
    actors.sort((a, b) => a.y - b.y);
    for (const actor of actors) {
      if (!isNearView(actor.x, actor.y, 180)) continue;
      if (actor === state.player) drawPlayer(actor);
      else drawEnemy(actor);
    }
  }

  function drawPlayer(p) {
    const aim = angleTo(p.x, p.y, state.mouse.wx, state.mouse.wy);
    ctx.save();
    if (p.invuln > 0) ctx.globalAlpha = 0.56 + Math.sin(state.time * 45) * 0.22;
    ctx.fillStyle = "rgba(0,0,0,0.36)";
    ellipse(p.x, p.y + 15, 25, 10);
    if (p.fury >= p.maxFury || p.invuln > 0.6) {
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = 0.4 + Math.sin(state.time * 8) * 0.12;
      ctx.strokeStyle = p.fury >= p.maxFury ? "#f6dfae" : p.accent;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(p.x, p.y, 35 + Math.sin(state.time * 6) * 4, 0, TAU);
      ctx.stroke();
      ctx.globalAlpha *= 0.36;
      ctx.lineWidth = 12;
      ctx.stroke();
      ctx.restore();
    }
    ctx.translate(p.x, p.y);
    ctx.rotate(aim);
    ctx.fillStyle = "rgba(0,0,0,0.18)";
    ctx.beginPath();
    ctx.moveTo(-20, -14);
    ctx.lineTo(-42, 0);
    ctx.lineTo(-20, 14);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.ellipse(0, 0, p.radius, p.radius * 0.84, 0, 0, TAU);
    ctx.fill();
    ctx.fillStyle = "#1a1413";
    ctx.beginPath();
    ctx.ellipse(5, 0, p.radius * 0.66, p.radius * 0.48, 0, 0, TAU);
    ctx.fill();
    ctx.fillStyle = p.accent;
    ctx.fillRect(4, -4, 26, 8);
    ctx.fillStyle = "#f6dfae";
    roundRect(26, -2, p.range * 0.48, 4, 2, true);
    ctx.fillStyle = p.accent;
    ctx.beginPath();
    ctx.arc(2, 0, 5, 0, TAU);
    ctx.fill();
    ctx.restore();
  }

  function drawEnemy(enemy) {
    const p = state.player;
    const aim = p ? angleTo(enemy.x, enemy.y, p.x, p.y) : 0;
    ctx.save();
    ctx.fillStyle = "rgba(0,0,0,0.34)";
    ellipse(enemy.x, enemy.y + enemy.radius * 0.7, enemy.radius * 1.05, enemy.radius * 0.38);
    ctx.translate(enemy.x, enemy.y);
    ctx.rotate(aim);
    if (enemy.hurt > 0) ctx.globalAlpha = 0.68 + Math.sin(state.time * 70) * 0.2;

    if (enemy.boss) {
      ctx.fillStyle = "#0f0d0d";
      ctx.beginPath();
      ctx.arc(0, 0, enemy.radius, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = enemy.accent;
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(0, 0, enemy.radius + 8 + Math.sin(state.time * 4) * 2, -0.2, TAU - 0.9);
      ctx.stroke();
      ctx.fillStyle = enemy.color;
      ctx.beginPath();
      ctx.ellipse(4, 0, enemy.radius * 0.72, enemy.radius * 0.54, 0, 0, TAU);
      ctx.fill();
      ctx.fillStyle = enemy.accent;
      ctx.fillRect(8, -5, enemy.radius * 1.04, 10);
    } else {
      ctx.fillStyle = enemy.color;
      ctx.beginPath();
      ctx.moveTo(enemy.radius, 0);
      ctx.lineTo(0, -enemy.radius * 0.86);
      ctx.lineTo(-enemy.radius * 0.78, 0);
      ctx.lineTo(0, enemy.radius * 0.86);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = enemy.accent;
      ctx.beginPath();
      ctx.arc(enemy.radius * 0.28, 0, enemy.radius * 0.28, 0, TAU);
      ctx.fill();
    }
    ctx.restore();

    if (enemy.hurt > 0 || enemy.boss || enemy.hp < enemy.maxHp) {
      const w = enemy.boss ? 108 : 54;
      const y = enemy.y - enemy.radius - 18;
      ctx.fillStyle = "rgba(0,0,0,0.58)";
      ctx.fillRect(enemy.x - w / 2, y, w, 6);
      ctx.fillStyle = enemy.boss ? "#d8a95a" : "#d84a3d";
      ctx.fillRect(enemy.x - w / 2, y, w * clamp(enemy.hp / enemy.maxHp, 0, 1), 6);
    }
  }

  function drawSlashes() {
    for (const slash of state.slashes) {
      const t = clamp(slash.life / slash.maxLife, 0, 1);
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = t * 0.62;
      ctx.fillStyle = slash.color;
      ctx.beginPath();
      ctx.moveTo(slash.x, slash.y);
      ctx.arc(slash.x, slash.y, slash.range, slash.angle - slash.arc / 2, slash.angle + slash.arc / 2);
      ctx.lineTo(slash.x, slash.y);
      ctx.fill();
      ctx.globalAlpha = t;
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(slash.x, slash.y, slash.range, slash.angle - slash.arc / 2, slash.angle + slash.arc / 2);
      ctx.stroke();
      ctx.restore();
    }
  }

  function drawShockwaves() {
    for (const wave of state.shockwaves) {
      const progress = clamp(wave.age / wave.maxLife, 0, 1);
      const radius = wave.radius * progress;
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = clamp(wave.life / wave.maxLife, 0, 1) * 0.75;
      ctx.strokeStyle = wave.color;
      ctx.lineWidth = wave.owner === "enemy" ? 8 : 5;
      ctx.beginPath();
      ctx.arc(wave.x, wave.y, radius, 0, TAU);
      ctx.stroke();
      ctx.globalAlpha *= 0.3;
      ctx.lineWidth = 18;
      ctx.stroke();
      ctx.restore();
    }
  }

  function drawParticles() {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (const particle of state.particles) {
      const t = clamp(particle.life / particle.maxLife, 0, 1);
      ctx.globalAlpha = t;
      ctx.fillStyle = particle.color;
      ctx.beginPath();
      ctx.arc(particle.x, particle.y, particle.size * (0.5 + t), 0, TAU);
      ctx.fill();
    }
    ctx.restore();
  }

  function drawDamageTexts() {
    ctx.save();
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    for (const text of state.damageTexts) {
      const t = clamp(text.life / text.maxLife, 0, 1);
      ctx.globalAlpha = t;
      ctx.font = `${text.crit ? 800 : 700} ${text.crit ? 22 : 16}px Inter, system-ui, sans-serif`;
      ctx.lineWidth = 4;
      ctx.strokeStyle = "rgba(0,0,0,0.65)";
      ctx.fillStyle = text.color;
      ctx.strokeText(text.value, text.x, text.y);
      ctx.fillText(text.value, text.x, text.y);
    }
    ctx.restore();
  }

  function drawScreenEffects() {
    const gradient = ctx.createRadialGradient(
      state.viewW / 2,
      state.viewH / 2,
      Math.min(state.viewW, state.viewH) * 0.24,
      state.viewW / 2,
      state.viewH / 2,
      Math.max(state.viewW, state.viewH) * 0.72
    );
    gradient.addColorStop(0, "rgba(0,0,0,0)");
    gradient.addColorStop(0.68, "rgba(0,0,0,0.28)");
    gradient.addColorStop(1, "rgba(0,0,0,0.72)");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, state.viewW, state.viewH);

    if (state.player) {
      const hpRatio = state.player.hp / state.player.maxHp;
      if (hpRatio < 0.34) {
        ctx.fillStyle = `rgba(216, 74, 61, ${0.12 * (1 - hpRatio / 0.34)})`;
        ctx.fillRect(0, 0, state.viewW, state.viewH);
      }
    }

    if (state.combatPulse > 0) {
      ctx.fillStyle = `rgba(246, 223, 174, ${state.combatPulse * 0.08})`;
      ctx.fillRect(0, 0, state.viewW, state.viewH);
    }

    if (state.flash > 0) {
      ctx.fillStyle = `rgba(246, 223, 174, ${Math.min(0.5, state.flash)})`;
      ctx.fillRect(0, 0, state.viewW, state.viewH);
    }
  }

  function ellipse(x, y, rx, ry) {
    ctx.beginPath();
    ctx.ellipse(x, y, rx, ry, 0, 0, TAU);
    ctx.fill();
  }

  function roundRect(x, y, width, height, radius, fill) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    if (fill) ctx.fill();
  }

  function isNearView(x, y, margin) {
    return x > state.camera.x - margin &&
      y > state.camera.y - margin &&
      x < state.camera.x + state.viewW + margin &&
      y < state.camera.y + state.viewH + margin;
  }

  function gameLoop(timestamp) {
    if (!state.lastTime) state.lastTime = timestamp;
    const dt = Math.min(0.034, (timestamp - state.lastTime) / 1000);
    state.lastTime = timestamp;

    if (state.mode === "playing") {
      update(dt);
    } else {
      updateAmbient(dt);
    }
    draw();
    requestAnimationFrame(gameLoop);
  }

  function bindEvents() {
    window.addEventListener("resize", resize);
    window.addEventListener("blur", () => {
      state.keys.clear();
      state.mouse.down = false;
    });

    window.addEventListener("keydown", (event) => {
      const gameplayKey = ["KeyW", "KeyA", "KeyS", "KeyD", "ArrowUp", "ArrowLeft", "ArrowDown", "ArrowRight", "Space", "KeyQ", "KeyE", "KeyR", "Escape", "KeyM", "Enter"].includes(event.code);
      if (gameplayKey) event.preventDefault();
      state.keys.add(event.code);

      if (event.code === "Escape") {
        togglePause();
        return;
      }
      if (event.code === "KeyM") {
        toggleSound();
        return;
      }
      if (state.mode === "menu" && event.code === "Enter") {
        beginGame();
        return;
      }
      if (state.mode === "gameover" && event.code === "Enter") {
        beginGame();
        return;
      }
      if (state.mode !== "playing" || event.repeat) return;
      if (event.code === "Space") dash();
      if (event.code === "KeyQ") castSkillOne();
      if (event.code === "KeyE") castSkillTwo();
      if (event.code === "KeyR") castUltimate();
    });

    window.addEventListener("keyup", (event) => {
      state.keys.delete(event.code);
    });

    canvas.addEventListener("pointermove", (event) => {
      const rect = canvas.getBoundingClientRect();
      state.mouse.sx = event.clientX - rect.left;
      state.mouse.sy = event.clientY - rect.top;
      updateMouseWorld();
    });

    canvas.addEventListener("pointerdown", (event) => {
      if (state.mode !== "playing") return;
      canvas.setPointerCapture(event.pointerId);
      const rect = canvas.getBoundingClientRect();
      state.mouse.sx = event.clientX - rect.left;
      state.mouse.sy = event.clientY - rect.top;
      updateMouseWorld();
      state.mouse.down = true;
      basicAttack();
    });

    canvas.addEventListener("pointerup", () => {
      state.mouse.down = false;
    });

    canvas.addEventListener("pointercancel", () => {
      state.mouse.down = false;
    });

    canvas.addEventListener("contextmenu", (event) => event.preventDefault());

    refs.classCards.forEach((card) => {
      card.addEventListener("click", () => {
        state.selectedClass = card.dataset.class;
        refs.classCards.forEach((item) => {
          const selected = item === card;
          item.classList.toggle("is-selected", selected);
          item.setAttribute("aria-selected", selected ? "true" : "false");
        });
      });
    });

    refs.startButton.addEventListener("click", beginGame);
    refs.restartButton.addEventListener("click", beginGame);
    refs.pauseButton.addEventListener("click", togglePause);
    refs.soundButton.addEventListener("click", toggleSound);
    refs.attackButton.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      if (state.mode === "playing") basicAttack();
    });
    refs.dashButton.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      if (state.mode === "playing") dash();
    });
    refs.skillOneButton.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      if (state.mode === "playing") castSkillOne();
    });
    refs.skillTwoButton.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      if (state.mode === "playing") castSkillTwo();
    });
    refs.ultimateButton.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      if (state.mode === "playing") castUltimate();
    });
  }

  function toggleSound() {
    state.muted = !state.muted;
    refs.soundButton.classList.toggle("is-muted", state.muted);
    showToast(state.muted ? "Sound muted" : "Sound on");
  }

  generateArena();
  bindEvents();
  resize();
  updateHUD();
  requestAnimationFrame(gameLoop);
})();
